// import { Component, OnInit } from '@angular/core';
// import {FormGroup, FormControl, Validators} from '@angular/forms';
// import {FormsModule,ReactiveFormsModule} from '@angular/forms';

// import { Router } from '@angular/router';
// // import { WorkoutService } from '../workout.service';


// @Component({
//   selector: 'app-sign-up',
//   templateUrl: './sign-up.component.html',
//   styleUrls: ['./sign-up.component.css']
// })
// export class SignUpComponent implements OnInit {

//   constructor(private workout: WorkoutService, private router: Router) { }
//   SigninForm: FormGroup;
//   // public user: User[] = [];
//   RegisterForm: FormGroup;
//   public username: string;
//   public isSignedIn: false;
//   public password: string;
//   public password_Re_Register :string;
//   public re_password :string;
//   formfirst =  true;
//   formtwo = true;
//   ngOnInit() {
//     this.RegisterForm = new FormGroup({
//       passwordRegister: new FormControl(null, Validators.required),
//       username: new FormControl(null, Validators.required ),
//       password_Re_Register: new FormControl(null,Validators.required),
//  });
//   }


// onSubmit() {

//   console.log('inside onsubit');
 
//   this.username =  this.RegisterForm.value.username;
//   this.password = this.RegisterForm.value.passwordRegister;
//   this.re_password = this.RegisterForm.value.password_Re_Register;
  

//   // console.log(this.type);
//   if(this.password === this.re_password){
  

      
//         }
//         else{
//           this.RegisterForm.reset();
//         }
//      } 
 
// }
