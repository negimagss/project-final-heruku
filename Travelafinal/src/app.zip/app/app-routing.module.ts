import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SignInComponent } from './sign-in/sign-in.component';
// import { SignUpComponent } from './sign-up/sign-up.component';
import { BookingComponent } from './booking/booking.component';
import { RegisterComponent } from './register/register.component';


const routes: Routes = [
  // {path: '', component: StoryComponent},
  {path: '', component: HomeComponent},
  // {path: 'register', component: SignInComponent},
  // {path: 'login', component: SignUpComponent},
  {path : 'booking', component : BookingComponent},
  {path : 'register', component : RegisterComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]

})
export class AppRoutingModule { }
